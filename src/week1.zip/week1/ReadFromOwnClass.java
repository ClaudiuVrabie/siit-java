package week1;

public class ReadFromOwnClass {
    public static void main(String[] args) {

        int i = 5;
        int i1 = 15;

        int sum = i + i1;
        System.out.println("Result is: " + sum);
    }
}
