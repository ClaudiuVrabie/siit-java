package week1;

public class ExampleClass {
    //class variable / static
    static int i1;

    // instance variable / non - static
    int i;

    // function - because of static keyword
    public static void main(String[] args) {

        // 5 & 15 are arguments
        myMethod(5,15);
    }

    // i & i1 are parameters
    // function - because of static keyword
    public static void myMethod(int i, int i1){
        int i2;
    }

    // method
    // because of static keyword not being present
    public void myMethod1(){

    }
}


