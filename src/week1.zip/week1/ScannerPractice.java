package week1;

import java.util.Scanner;

public class ScannerPractice {
//    public static void main(String[] args) {
//
//        Scanner ex = new Scanner(System.in);
//
//        System.out.println("What is your age?");
//        int userAge = ex.nextInt();
//
//
//        System.out.println("What is your name?");
//      String username = ex.nextLine();
//
//
//        System.out.println("The user name is: " + username +  "," + " " + "user age is: " + userAge);
//    }

 public static void main(String[] args) {

     Scanner pr = new Scanner(System.in);
     char c = 67;
     char l = 76;
     char a = 65;
     char u = 85;
     char d = 68;
     char i = 73;
     System.out.println("Name is: " + c + l + a + u + d + i + u);
 }








}
