package library;

public class ArtAlbums extends Book {

    public int paperQuality(int gsm) {
        System.out.println("The paper quality grams per meter is: ");

        return gsm;
    }
}