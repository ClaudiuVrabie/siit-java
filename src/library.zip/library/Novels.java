package library;

public class Novels extends Book {

    public String type(String novelType) {

        return "Novel type is: " + novelType;
    }

}
