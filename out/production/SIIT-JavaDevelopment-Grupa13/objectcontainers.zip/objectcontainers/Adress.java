package objectcontainers;

import java.util.List;

public class Adress  {

    private String street;
    private int streetNumber;

    public Adress(String street, int streetNumber) {
        this.street = street;
        this.streetNumber = streetNumber;
    }

}
